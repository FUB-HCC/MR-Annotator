var searchData=
[
  ['color_5flaser_5factive',['COLOR_LASER_ACTIVE',['../class_main_controller.html#ac4d730aec311b372fbab3df611616c39',1,'MainController']]],
  ['color_5flaser_5fcalibrating',['COLOR_LASER_CALIBRATING',['../class_main_controller.html#ab6b5ed4f310f41ff4c670730cea795cf',1,'MainController']]],
  ['controllerdisplay',['controllerDisplay',['../class_main_controller.html#a4128337a4a66c2f42733bde7e955480e',1,'MainController.controllerDisplay()'],['../class_quick_example_controller.html#ae355a3da0fec721e1bb6a6f9e3195bcb',1,'QuickExampleController.controllerDisplay()']]]
];
