var searchData=
[
  ['xposmax',['xPosMax',['../class_main_controller.html#a5ddbd478a310f692768f4ee57ca2a0db',1,'MainController.xPosMax()'],['../class_quick_example_controller.html#a420dc7e21a3f6f36bb44b343b4c189de',1,'QuickExampleController.xPosMax()']]],
  ['xposmin',['xPosMin',['../class_main_controller.html#aacb4ea4d9abb0b587e49036208f2d28f',1,'MainController.xPosMin()'],['../class_quick_example_controller.html#ac28cc5d49ee1c3d1e8baba5b9811bb06',1,'QuickExampleController.xPosMin()']]]
];
