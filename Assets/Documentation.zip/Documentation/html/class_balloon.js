var class_balloon =
[
    [ "CustomizeInitialAppearance", "class_balloon.html#a03b60ea909a0973c66e24136027215d0", null ],
    [ "Enable", "class_balloon.html#abb6dda33d0f39b0992489ff616231ecc", null ],
    [ "EnableAudio", "class_balloon.html#ab195102c59aecb43c903617157d6f579", null ],
    [ "GetBalloonColor", "class_balloon.html#a6c7da4b92abafb8e5ab91612a8c257b0", null ],
    [ "InitializeValues", "class_balloon.html#a32d9329dd5eef1309747e7d8c24f7d01", null ],
    [ "PickNewColor", "class_balloon.html#a514694e6653ec250957ff02ed1af28b7", null ],
    [ "ResetBalloon", "class_balloon.html#ac38c9d93b9037788cd4b6070fc297458", null ],
    [ "SetVisible", "class_balloon.html#a24b54467ef23a5fa269aee1b7564d684", null ]
];